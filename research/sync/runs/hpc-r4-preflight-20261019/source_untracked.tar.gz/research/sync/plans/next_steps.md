# 当前进度与下一步执行地点

更新：2026-10-19，HPC 环境/R1/R2/R3 已实际执行并回传，依据见 runs/ 与本轮任务报告。以下不自动启动新的实验。

| 工作 | 地点 | 状态 / 关卡 |
|---|---|---|
| uv Python 3.11.15 隔离项目环境 | HPC | 已完成；15 包固定版本与哈希，导入及 uv pip check 通过 |
| R1 原始完整测试 | HPC，CPU线程<=2 | 已完成；85 collected/85 passed，0 skipped，33.64s，JUnit/日志已回传 |
| R2 保存数据重分析/重绘 | HPC，隔离输入副本 | 已完成计算；17 PDF、18 TeX，三个汇总 JSON 均与历史基线在 1e-10 内一致，无跳过分支 |
| R3 默认 GOSC 单 mission | HPC | 已完成；seed=3000，113 slots，found=8，false=0，uplink symbols=19051，bits=19623；N=1，不作显著性/算法优势结论 |
| P0 论文公式/图表—源码映射，R2 论文逐图表审阅 | 本地阅读/编辑；新增统计计算放 HPC | 下一项必要工作；复现协议已补齐，完整 paper-code-map 和论文 PDF 对照仍未完成 |
| P2 精读、Gap Matrix、RQ 与拒稿自查 | 本地阅读/文档；模型/数据计算放 HPC | 文献与问题定义关卡仍在；不能把已有 GOSC ToM 记作新方法 |
| R4 成本匹配 paired seeds、独立校准/评估协议 | 本地写协议，计算全部 HPC | 待上面证据/资源预算固定后执行；本轮未启动完整 campaign |
| R5 cached/live LLM、R6 全部论文表图验收 | HPC 计算，本地阅读/审阅 | 未完成；本次对已有 LLM 结果的重分析不是 cache replay/live 调用 |
| P3 M0/M1 训练与新方法消融 | 本地编辑，测试/训练/统计全部 HPC | 未启动；依赖 P1/P2 关卡与明确实验范围 |

原 gosc/、experiments/、tests/、results/、缓存、LICENSE 的哈希前后不变。HPC 是运行事实源，完成状态与本地镜像状态分别查看 status.json 和 receipts/*.json。已修复 pytest 临时符号链接造成的首次 R1 回传阻断，未改变或重跑原测试。

下一步无需在本地重跑测试，也无需重装 HPC 环境；本地完成文献/协议/图表审核。后续新的测试、统计、仿真与训练继续在 HPC，按同一登记与回传流程执行。
