# Issues and limits

- [RUN] HPC glibc2.27, driver545.29.06; official latest docs require550+, pinned Ollama0.11.11 docs require531+ and listL40. Compatibility still needs actual inference verification.
- [RUN] HPC github.com timed out; official release-assets redirect reachable but ranged probe1048576bytes/22.8s (~45.9KB/s). Dedicated hpc-ollama-install-20261020 terminated withSIGTERM (-15), before installation/execution. Partial archive preserved in .local/ollama/downloads/*hpc-direct.partial.tgz. Switching to local relay; transient Windows TLS close-notify errors retained in command outputs and retries resume.
- [RUN] Prior ordered queue stopped: ordered-c-belief-20261019 raised AttributeError for module.main. Original experiments/run_belief_divergence.py exposes simulate/fill_table through an if-main block. No scientific pool started for that stage; completed preceding stages are retained. Adapter repair and explicit resume remain needed; deployment alone does not fix this queue.
- Model tags/quantization/digests are recorded as downloaded now; no assumption they equal the authors historical model snapshots. Smoke choices are environment checks, not scientific missions or quality evidence.
- User-level detached service survives SSH logout, not guaranteed container/HPC reboot. Restart through scripts/hpc_ollama.py start; no root-level service or network exposure.
