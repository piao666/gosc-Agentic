"""Registered HPC-only forensic scan; never alters simulation results."""
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if (os.name != 'posix' or os.getuid() != 8301880 or
            str(root) != '/home/u202520081000097/jupyterlab/Paper/gosc' or
            not os.environ.get('GOSC_OUTPUT_DIR')):
        raise RuntimeError('Registered HPC execution required')
    data = json.loads(args.results.read_text())
    examples = []
    decisions = violations = material = 0
    maximum_excess = 0.
    cases = {}
    for row in data['rows']:
        path = args.results.parent / row['observation']['path']
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['observation']['sha256']:
            raise ValueError('Input hash mismatch')
        with gzip.open(path, 'rt') as stream:
            for line in stream:
                d = json.loads(line)
                if d['event'] != 'decision':
                    continue
                decisions += 1
                symbols = [x['symbols'] for x in d['selected']]
                total = sum(symbols)
                if total > d['budget']:
                    excess = total - d['budget']
                    violations += 1
                    material += excess > 1e-9
                    maximum_excess = max(maximum_excess, excess)
                    cases[row['case_id']] = cases.get(row['case_id'], 0) + 1
                    if len(examples) < 20:
                        examples.append(dict(seed=row['seed'], case_id=row['case_id'],
                            t=d['t'], sender=d['sender'], budget=d['budget'],
                            total=total, fsum=math.fsum(symbols), excess=excess,
                            budget_hex=float(d['budget']).hex(), total_hex=float(total).hex(),
                            selected=d['selected']))
    report = dict(results_sha256=hashlib.sha256(args.results.read_bytes()).hexdigest(),
        decisions=decisions, strict_violations=violations, excess_over_1e_9=material,
        max_excess=maximum_excess, by_case=cases, examples=examples,
        scope='Forensic diagnosis only; original audit failure and experiment preserved')
    out = Path(os.environ['GOSC_OUTPUT_DIR']) / 'diagnosis.json'
    with out.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'examples'}))


if __name__ == '__main__':
    main()
