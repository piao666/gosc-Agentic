# 下一步任务安排（2026-10-20）

权威进度综述：research/reports/progress_review_2026-10-20.md。HPC当前无运行中的复验任务；原队列failed。Ollama与3模型已就绪，完整cached/live科学任务尚未执行。原23阶段中4执行完成、1失败、18未运行，不代表阶段百分比对应论文完成比例。

## 严格顺序

1. 本地完善比较器和诊断设计，HPC先重分析现有输出：参数选择22条差异、C-frontier479条、C-where364条。核对显式匹配键、唯一性和覆盖率；0比较标为未比较。完成时间差异分别228/146条，原因未定位，不能当作只存在舍入误差。已完成4阶段不整批重跑。
2. 核验原隔离工作区/输入/输出、旧失败无残留worker和新源码快照，形成独立resume清单/新runID；继续C-belief1400项，再C-analysis（成本匹配及配对CI）。main入口适配器修复已有10项HPC回归通过。
3. HPC依序现实链路noise23400→overhead82600→shared18400候选任务，再fresh；先核验fresh实际范围与预算。原72h为安全上限，续跑不得静默重置。
4. HPC依序main-sweeps→revision-rest→joint→scheduler→theory→value-fidelity→fidelity-analysis。
5. HPC cached-llm严格禁HTTP，然后live-llm用新缓存、真实3模型、固定digest/context/seed，记录tokens/时间/通信成本、失败及格式错误；禁止planner回退冒充成功。
6. HPC sensitivity→sensitivity-fresh→genie-fresh→final-replot与总审计。38候选扩展单列，不改严格37主轨。

## 并行研究文档

本地精读E:\Papers（只读原文），完成research/literature/Research-Gap-Matrix.md、research/ideas/RQ_v1.md、research/ideas/reviewer_objections.md。所有统计/推理/测试仍HPC；CPU并发<=2，科学worker数值线程1。P1未验收、P2未过关，新方法M0/M1实现与训练不在本次安排的已执行范围。

## 保留边界

独立校准1000–1079原流程缺失，作为上游资料缺口保留；公开0–99选参不能替代。A1与选参后fresh重复使用3000–3099，不能合并成更大的独立N。所有原结果/缓存/失败记录保留。今天仅只读进度审计，没有启动长队列；执行与同步完成分看status和receipts。

历史安排备份：archive/next_steps_before_review_2026-10-20.md；冻结原协议未改。
