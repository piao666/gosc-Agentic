# 研究进度与证据入口

文档更新：2026-10-23（Asia/Shanghai）。最新HPC合同验收与交叉审计已完成；任务收益证据仍截至2026-10-22。当前交付见[最小接口与交付报告](reports/minimal_interface_delivery_2026-10-23.md)。

[CODE] 本轮起点为研究分支`research/progress-audit-2026-10-19`的`4ff4147`。10月22日已核验GitHub main停留在`876fc52`；该远端观察本轮未刷新。历史run中的`876fc52`/dirty/source SHA是执行时事实，不倒填为归档commit。

## 当前判断

| 阶段 | 已有证据 | 验收边界 |
|---|---|---|
| P0 | 环境、文献清单、GOSC纸码映射 | 全部元数据/出版状态仍部分核验 |
| P1 | HPC85测试；A1 1200任务；主队列23阶段已评估、22正常退出；图表17PDF/18TeX | 原1000–1079校准、作者cache生成链及部分历史差异未解决 |
| P2 | 13旧记录+29选段笔记、Gap Matrix、RQv2、拒稿自查 | 非42篇全部通读、非新颖性证明 |
| P3探索 | 1248校准+260验证；免费特权6比较0通过；23摘要测试及96条件回放 | cache尚未进入任务策略，未测付费摘要净任务收益 |
| P3实现合同 | 10月23日：26新增合同+85原测试+18旧codec合同=129通过；47份交付副本哈希审计通过 | 默认配置下的估值专用pose与RTT状态机已实现；paid系统/效果实验仍未完成 |
| P4/P5 | 有研究报告和协议资产 | 新方法完整实验、正式稿件未完成；复杂训练No-Go |

上述[RUN]事实引用既有报告，本页不是新run或实时调度状态。

## 按问题找证据

- 当前方案：[低成本同步与最简单估值接口协议](protocols/receiver_summary_minimal_protocol_v1.md)；部分接口合同已实现和测试，paid任务主试验仍未冻结/未运行。
- 可提交产物：[R2/R3成果包](artifacts/r2-r3-20261019/README.md)，47份原输出副本，尚未Git提交/推送。
- 原生复验：[总审计](reports/final_reproduction_audit_2026-10-22.md)、[图表主张矩阵](reports/claim_acceptance_matrix_2026-10-22.md)、[纸码映射](logs/GOSC_paper_code_map.md)。
- 新方向的负结果：[特权诊断](reports/receiver_headroom_pilot_2026-10-22.md)。
- 同步信息/成本：[摘要审计](reports/receiver_summary_information_cost_audit_2026-10-22.md)。96条件复用旧轨迹，不是96独立世界或新方法收益验证。
- 文献：[阅读范围](literature/reading_review_2026-10-22.md)、[Gap Matrix](literature/Research-Gap-Matrix-2026-10-22.md)、[RQv2](ideas/RQ_v2.md)。
- 当前动作：[下一步](sync/plans/next_steps.md)；机器摘要：[project_status.json](sync/project_status.json)。二者是研究判断，不替代run/status与回执。
- 本轮：[任务说明](logs/minimal-interface-2026-10-23/task_brief.md)、[交付/验收报告](reports/minimal_interface_delivery_2026-10-23.md)；前一轮[静态审查](reports/status_and_protocol_review_2026-10-23.md)保留历史含义。

## 读取顺序与保护

先读本页与最新专项报告，再按需回到冻结协议、run manifest/status、outputs和receipts。旧报告中的“未运行”只表示当时状态；当前实施需遵守根AGENTS.md的HPC规则，说明书中的Windows计算示例不再是执行入口。

Git仅保存非忽略文件。原始输出/图件有部分按忽略规则留在本地与HPC；R2/R3另备白名单副本。源码同步、HPC执行与回传本轮已执行；Git提交、推送和分支合并未执行。在线manifest或回执不是完整数据副本。
