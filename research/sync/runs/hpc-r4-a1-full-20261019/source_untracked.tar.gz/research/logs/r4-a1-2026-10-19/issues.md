# Issues and negative evidence

No A1 simulation started at preregistration. Retain all failures, target misses, partial task outcomes and historical discrepancies. Prior R3 seed3000 is an explicit permitted repeat.
