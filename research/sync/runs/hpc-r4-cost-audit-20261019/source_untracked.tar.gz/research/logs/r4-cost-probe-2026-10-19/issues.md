# Issues and negative evidence

No execution started at preregistration. Retain all failures, timeouts and incomplete scientific outcomes.
