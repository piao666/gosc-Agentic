# 当前进度与下一步执行地点

更新：2026-10-19。本轮完成原文—代码—图表映射、印刷数值核对与R4预登记。

| 工作 | 地点 | 真实状态 |
|---|---|---|
| Python3.11环境、R1 85/85、原R2三模块、R3单mission | HPC | 已完成；历史run与输出保留 |
| GOSC v1全编号项目映射 | 本地只读阅读/文档 | 已完成5式/5图/13表/Algorithm1；表I跨论文判断未独立全文验证 |
| 印刷数值/参数/冻结点审计 | HPC计算；本地PDF阅读 | 9表405单元，原8表全符；VI缺5格，追加原table-only helper后全符；25默认字段、6冻结点已核验 |
| 可视化差异 | 本地阅读 | Fig2第三subplot minor log labels重叠已登记；未覆盖原图，不冒称全部版式零差异 |
| R4候选/seed元数据预检 | HPC | 已完成；所有候选各100个eval seed，主结果search37/rescue38；当前gen已核对 |
| R4-A0有界pilot | 本地写执行器，计算全部HPC | 协议/JSON已定：9000–9009、2场景、3arms、60missions、workers<=2、20min预算；尚未执行，执行器尚未实现 |
| R4完整严格复现与38候选敏感性 | HPC | 分轨预登记；六场景100seeds完整任务未启动，先依据pilot成本定预算 |
| P2关键文献、Gap Matrix、RQ与拒稿自查 | 本地阅读/文档，统计模型计算HPC | 未过关；不能将原ToM/TV/bits/AoI记作创新 |
| R5 cached/live LLM与新M0/M1训练 | HPC | 未执行；新模型/训练不由当前审计自动触发 |

论文地图：research/logs/GOSC_paper_code_map.md；审计报告：research/reproduction/figure_table_audit_2026-10-19.md；R4协议：research/protocols/r4_protocol_v1.md。完整P1仍未验收。任何新计算继续登记、同步和保存负结果；本文不是已运行mission记录。
