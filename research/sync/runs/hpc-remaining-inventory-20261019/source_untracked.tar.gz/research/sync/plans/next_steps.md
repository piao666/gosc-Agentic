# 当前进度与下一步执行地点

更新：2026-10-19。R4-A0已完成60条mission；其余四场景成本探测另完成24条mission，17项测试与独立审计通过。完整A1现已完成1200条mission、600配对，28测试与独立审计通过，逐seed主指标/UL与作者记录全部一致；P1整体验收仍未完成。

| 工作 | 地点 | 真实状态 |
|---|---|---|
| Python3.11环境、R1 85/85、原R2三模块、R3单mission | HPC | 已完成；历史run与输出保留 |
| GOSC v1全编号项目映射 | 本地只读阅读/文档 | 已完成5式/5图/13表/Algorithm1；表I跨论文判断未独立全文验证 |
| 印刷数值/参数/冻结点审计 | HPC计算；本地PDF阅读 | 9表405单元，原8表全符；VI缺5格，追加原table-only helper后全符；25默认字段、6冻结点已核验 |
| 可视化差异 | 本地阅读 | Fig2第三subplot minor log labels重叠已登记；未覆盖原图，不冒称全部版式零差异 |
| R4候选/seed元数据预检 | HPC | 已完成；所有候选各100个eval seed，主结果search37/rescue38；当前gen已核对 |
| R4-A0有界pilot | 本地写执行器，计算全部HPC | 已完成：9000–9009、2场景、3arms、60missions，最大并发2；20.11s登记墙钟；9项执行器测试与数据审计通过，首次0mission导入失败保留 |
| R4-A1完整冻结复现 | HPC | 已完成：六场景×两方案×100seeds=1200条，574.59s，28测试/独立审计通过；主指标与UL逐seed匹配1200/1200 |
| R4-B38候选敏感性、C估值frontier及独立校准 | HPC | 仍未执行；分别核验范围/成本与公平协议，不由A1完成自动触发 |
| P2关键文献、Gap Matrix、RQ与拒稿自查 | 本地阅读/文档，统计模型计算HPC | 未过关；不能将原ToM/TV/bits/AoI记作创新 |
| R5 cached/live LLM与新M0/M1训练 | HPC | 未执行；新模型/训练不由当前审计自动触发 |

论文地图：research/logs/GOSC_paper_code_map.md；审计报告：research/reproduction/figure_table_audit_2026-10-19.md；R4协议：research/protocols/r4_protocol_v1.md。完整P1仍未验收。任何新计算继续登记、同步和保存负结果；本文不是已运行mission记录。

实际pilot报告：research/reproduction/r4_a0_report_2026-10-19.md；冻结计划不改，当前执行状态见research/protocols/r4_a0_execution_2026-10-19.json。N10不作正式方法优势结论。


## 历史成本探测记录（制定时A1未启动）

[RUN] search-K10、search-clustered、rescue-W50、rescue-snr-5各GOSC/冻结periodic、seeds9010–9012共24条完成，17项测试/独立审计通过。六场景1200条A1预计575.8s，建议硬上限1860s、单条120s、并发2，每worker线程1；预算为小样本外推，不含可选Genie/B/C/LLM/训练。下一计算地点为HPC；完整A1待范围确认后准备执行器，未自动启动。报告：research/reproduction/r4_cost_probe_report_2026-10-19.md；预算：research/protocols/r4_a1_budget_proposal_2026-10-19.json。P1整体仍未验收。


## 完整R4-A1执行更新（2026-10-19）

[RUN] 已执行六场景两方案seeds3000–3099共1200条、600配对；28项测试及独立统计/数据审计通过。登记墙钟574.586676s，0程序失败/超时/中断。1200条主指标/上行symbols逐seed与作者保存值一致；不宣称全部轨迹历史比对或新方法贡献。periodic Search-W100/K10均值略未达冻结目标；所有search时间差CI及rescue-snr-5获救差CI跨0，负结果保留。报告research/reproduction/r4_a1_report_2026-10-19.md，实际状态research/protocols/r4_a1_execution_2026-10-19.json。B/C、独立校准与R5LLM/P2关卡仍待推进，完整P1未验收，未启动训练。
